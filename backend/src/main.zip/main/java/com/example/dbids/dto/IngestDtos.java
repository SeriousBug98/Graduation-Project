package com.example.dbids.dto;

public class IngestDtos {
    public static class IngestLogRequest {
        public String executedAt;     // nullable (null이면 서버에서 now)
        public String userId;         // 필수: 이메일 문자열
        public String adminId;        // 필수: AdminUser UUID (FK)
        public String sqlRaw;         // 필수
        public Integer returnRows;    // 필수(>=0)
        public String status;         // 필수: "SUCCESS" | "FAILURE"
    }
}
